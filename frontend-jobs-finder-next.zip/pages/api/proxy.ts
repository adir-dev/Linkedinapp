
import type { NextApiRequest, NextApiResponse } from 'next'

const ALLOWLIST = [
  /^https?:\/\/boards-api\.greenhouse\.io\//i,
  /^https?:\/\/api\.lever\.co\//i,
]

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const url = (req.query.url as string) || ''
  if (!url) return res.status(400).json({ error: 'Missing url' })
  if (!ALLOWLIST.some((rx) => rx.test(url))) return res.status(400).json({ error: 'Target not allowed' })
  try {
    const upstream = await fetch(url, { headers: { 'accept': 'application/json' } })
    const text = await upstream.text()
    const ct = upstream.headers.get('content-type') || 'application/json; charset=utf-8'
    res.setHeader('content-type', ct)
    res.setHeader('cache-control', 's-maxage=300, stale-while-revalidate=60')
    res.status(upstream.status).send(text)
  } catch (e) {
    res.status(502).json({ error: 'Upstream fetch failed' })
  }
}

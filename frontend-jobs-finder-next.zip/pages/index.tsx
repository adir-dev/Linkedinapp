import FrontendJobsFinder from '../components/FrontendJobsFinder'
export default function Home(){return <main className="p-6"><FrontendJobsFinder proxyBase="/api/proxy"/></main>}

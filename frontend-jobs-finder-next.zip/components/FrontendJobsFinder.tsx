
'use client'
import React, { useMemo, useState } from 'react'

export type CompanyInput = { company: string; ats: 'greenhouse' | 'lever' | 'auto'; slug: string }
export type Job = { company: string; title: string; location?: string; remote?: boolean | null; url: string; department?: string | null; created_at?: string | null; ats: 'greenhouse' | 'lever' }

const DEFAULT_COMPANIES: CompanyInput[] = [
  { company: 'Acme Corp', ats: 'auto', slug: 'acmecorp' },
  { company: 'Beta Inc', ats: 'greenhouse', slug: 'betainc' },
  { company: 'Gamma LLC', ats: 'lever', slug: 'gammallc' },
]

const GH = (slug: string) => `https://boards-api.greenhouse.io/v1/boards/${slug}/jobs`
const LEVER = (slug: string) => `https://api.lever.co/v0/postings/${slug}?mode=json`

const cx = (...s: Array<string | undefined | null | false>) => s.filter(Boolean).join(' ')

function toCSV(rows: Job[]) {
  const headers = ['company','title','location','remote','url','department','created_at','ats']
  const esc = (v: any) => { const s = v == null ? '' : String(v); return s.includes(',')||s.includes('"')||s.includes('\n') ? '"'+s.replace(/"/g,'""')+'"' : s }
  const lines = [headers.join(',')].concat(rows.map(r=>headers.map(h=>esc((r as any)[h])).join(',')))
  return lines.join('\n')
}

export default function FrontendJobsFinder({ proxyBase = '/api/proxy' }: { proxyBase?: string }) {
  const [companiesText, setCompaniesText] = useState(() => DEFAULT_COMPANIES.map(c => `${c.company},${c.ats},${c.slug}`).join('\n'))
  const [regex, setRegex] = useState('(front[- ]?end|frontend|ui engineer|react|angular|vue)')

  const companies = useMemo<CompanyInput[]>(() => {
    const rows = companiesText.split(/\n+/).map(l=>l.trim()).filter(Boolean)
    const parsed: CompanyInput[] = []
    for (const row of rows) {
      const [company, ats, slug] = row.split(',').map(s => (s || '').trim())
      if (!company || !slug) continue
      const a = (ats || 'auto').toLowerCase()
      parsed.push({ company, ats: (a==='greenhouse'||a==='lever'?a:'auto') as any, slug })
    }
    return parsed
  }, [companiesText])

  const [jobs, setJobs] = useState<Job[]>([])
  const [loading, setLoading] = useState(false)

  const fetcher = async (url: string) => {
    const res = await fetch(`${proxyBase}?url=${encodeURIComponent(url)}`)
    if (!res.ok) throw new Error(`Fetch failed ${res.status}`)
    return res.json()
  }

  const run = async () => {
    setLoading(true); setJobs([])
    const rx = new RegExp(regex, 'i')
    const results: Job[] = []

    const detectATS = async (slug: string): Promise<'greenhouse'|'lever'|null> => {
      try {
        const r = await Promise.race([
          fetcher(GH(slug)).then(()=> 'greenhouse' as const),
          fetcher(LEVER(slug)).then(()=> 'lever' as const),
        ]); return r
      } catch { return null }
    }

    for (const c of companies) {
      const slug = c.slug || c.company.toLowerCase().replace(/\s+/g,'')
      let ats = c.ats
      if (ats==='auto') { const d = await detectATS(slug); if (!d) continue; ats=d }

      if (ats==='greenhouse') {
        const data = await fetcher(GH(slug))
        const out: Job[] = (data.jobs||[]).map((j:any)=>{
          const loc = typeof j.location==='object' && j.location ? j.location.name : j.location || ''
          const dep = Array.isArray(j.departments) && j.departments[0] ? j.departments[0].name : null
          let remote: boolean | null = null
          if (Array.isArray(j.metadata)) {
            const mt = j.metadata.find((m:any)=>(m.name||'').toLowerCase()==='workplace type')
            if (mt && typeof mt.value==='string') remote = mt.value.toLowerCase().includes('remote')
          }
          return { company:c.company, title:j.title||'', location:loc, remote, url:j.absolute_url||'', department:dep, created_at:j.updated_at||j.created_at||null, ats:'greenhouse' }
        })
        for (const j of out) if (rx.test(j.title)) results.push(j)
      }

      if (ats==='lever') {
        const data = await fetcher(LEVER(slug))
        const postings = Array.isArray(data)?data:(data?.data||[])
        const out: Job[] = postings.map((j:any)=>{
          const title = j.text || j.title || ''
          const cat = j.categories || {}
          const loc = Array.isArray(cat.location)?cat.location.map((l:any)=>l.name).join(', '):cat.location||''
          const dep = j.department || cat.team || null
          let created: string | null = null
          if (j.createdAt) { try { created = new Date(Number(j.createdAt)).toISOString() } catch {} }
          return { company:c.company, title, location:loc, remote:null, url:j.hostedUrl||j.applyUrl||'', department:dep, created_at:created, ats:'lever' }
        })
        for (const j of out) if (rx.test(j.title)) results.push(j)
      }
    }

    results.sort((a,b)=> (Date.parse(b.created_at||'0') - Date.parse(a.created_at||'0')))
    setJobs(results); setLoading(false)
  }

  const download = () => {
    const blob = new Blob([toCSV(jobs)], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob); const a = document.createElement('a')
    a.href = url; a.download = `frontend_jobs_${new Date().toISOString().slice(0,10)}.csv`; a.click(); URL.revokeObjectURL(url)
  }

  return (
    <div className="min-h-screen p-6 grid gap-6">
      <header className="flex flex-col gap-2">
        <h1 className="text-2xl font-semibold">Frontend Jobs Finder (ATS-based)</h1>
        <p className="text-sm text-gray-600">Queries public Greenhouse/Lever feeds via an allowlisted proxy. No LinkedIn scraping.</p>
      </header>
      <section className="grid md:grid-cols-2 gap-4">
        <div className="grid gap-2">
          <label className="text-sm font-medium">Companies (CSV rows: company,ats,slug)</label>
          <textarea className="border rounded-xl p-3 min-h-[160px] bg-white" value={companiesText} onChange={e=>setCompaniesText(e.target.value)} />
          <p className="text-xs text-gray-500">Example: Acme Corp,auto,acmecorp</p>
        </div>
        <div className="grid gap-3">
          <div className="grid gap-2">
            <label className="text-sm font-medium">Title Regex Filter</label>
            <input className="border rounded-xl p-2 bg-white" value={regex} onChange={e=>setRegex(e.target.value)} placeholder="(frontend|react|ui engineer)" />
            <p className="text-xs text-gray-500">Only titles matching this regex are kept.</p>
          </div>
          <div className="flex gap-2">
            <button onClick={run} disabled={loading || companies.length===0} className={cx('px-4 py-2 rounded-xl shadow text-white', loading?'bg-gray-400':'bg-black hover:opacity-90')}>{loading?'Fetching…':`Fetch (${companies.length})`}</button>
            <button onClick={download} disabled={jobs.length===0} className={cx('px-4 py-2 rounded-xl shadow border', jobs.length===0?'bg-gray-200 text-gray-500':'bg-white hover:bg-gray-100')}>Download CSV</button>
          </div>
        </div>
      </section>
      <section className="bg-white rounded-2xl shadow p-3 overflow-hidden">
        <div className="flex items-center justify-between px-2 py-3"><h2 className="font-medium">Results ({jobs.length})</h2></div>
        <div className="overflow-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-100">
              <tr><th className="text-left p-2">Company</th><th className="text-left p-2">Title</th><th className="text-left p-2">Location</th><th className="text-left p-2">Remote</th><th className="text-left p-2">Department</th><th className="text-left p-2">Created</th><th className="text-left p-2">ATS</th><th className="text-left p-2">Apply</th></tr>
            </thead>
            <tbody>
              {jobs.map((j,i)=>(
                <tr key={i} className="border-t">
                  <td className="p-2 whitespace-nowrap">{j.company}</td>
                  <td className="p-2 whitespace-nowrap">{j.title}</td>
                  <td className="p-2 whitespace-nowrap">{j.location||''}</td>
                  <td className="p-2 whitespace-nowrap">{j.remote==null?'':j.remote?'Yes':'No'}</td>
                  <td className="p-2 whitespace-nowrap">{j.department||''}</td>
                  <td className="p-2 whitespace-nowrap">{j.created_at?new Date(j.created_at).toLocaleString():''}</td>
                  <td className="p-2 whitespace-nowrap uppercase">{j.ats}</td>
                  <td className="p-2 whitespace-nowrap"><a className="text-blue-600 underline" href={j.url} target="_blank" rel="noreferrer">Open</a></td>
                </tr>
              ))}
              {jobs.length===0 && (<tr><td colSpan={8} className="p-6 text-center text-gray-500">No results yet. Enter a few companies and click Fetch.</td></tr>)}
            </tbody>
          </table>
        </div>
      </section>
      <footer className="text-xs text-gray-500"><p>This tool queries public ATS endpoints and respects site Terms.</p></footer>
    </div>
  )
}
